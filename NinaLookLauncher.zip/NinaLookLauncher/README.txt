NINA LOOK STUDIO LAUNCHER
1. Abre esta carpeta en Android Studio (File > Open) y espera el Gradle Sync.
2. (Opcional) Fuente manuscrita: descarga "Great Vibes" desde fonts.google.com,
   renombra el archivo a great_vibes.ttf y ponlo en app/src/main/res/font/
3. Build > Build APK(s). Instala el APK en la TV (USB o ADB) y elige
   "Nina Look Studio" como pantalla de inicio cuando Android TV lo pregunte.
