package cl.ninalook.launcher

import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class AppItem(val label: String, val icon: Drawable, val intent: Intent)

class MainActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Fuente manuscrita: si agregas res/font/great_vibes.ttf se usa; si no, "cursive" del sistema
        val title = findViewById<TextView>(R.id.title)
        val fontId = resources.getIdentifier("great_vibes", "font", packageName)
        title.typeface = if (fontId != 0)
            ResourcesCompat.getFont(this, fontId)
        else Typeface.create("cursive", Typeface.BOLD_ITALIC)

        recycler = findViewById(R.id.recycler)
        recycler.layoutManager = GridLayoutManager(this, 5)

        // En un launcher el botón Atrás no debe hacer nada
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* nada */ }
        })
    }

    override fun onResume() {
        super.onResume()
        recycler.adapter = Adapter(loadItems())
        recycler.post { recycler.getChildAt(0)?.requestFocus() }
    }

    private fun loadItems(): List<AppItem> {
        val pm = packageManager
        val apps = LinkedHashMap<String, AppItem>()

        listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER).forEach { cat ->
            val query = Intent(Intent.ACTION_MAIN).addCategory(cat)
            pm.queryIntentActivities(query, 0).forEach { ri ->
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || apps.containsKey(pkg)) return@forEach
                val launch = pm.getLeanbackLaunchIntentForPackage(pkg)
                    ?: pm.getLaunchIntentForPackage(pkg) ?: return@forEach
                apps[pkg] = AppItem(ri.loadLabel(pm).toString(), ri.loadIcon(pm), launch)
            }
        }

        val sorted = apps.values.sortedBy { it.label.lowercase() }
        val settings = AppItem(
            "Configuración",
            getDrawable(R.drawable.ic_settings)!!,
            Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return sorted + settings   // el engranaje queda al final
    }

    private inner class Adapter(private val items: List<AppItem>) :
        RecyclerView.Adapter<Adapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.icon)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val item = items[position]
            h.icon.setImageDrawable(item.icon)
            h.itemView.contentDescription = item.label
            h.itemView.setOnClickListener {
                try { startActivity(item.intent) } catch (_: Exception) { }
            }
            h.itemView.setOnFocusChangeListener { v, focused ->
                val s = if (focused) 1.15f else 1f
                v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            }
        }
    }
}
